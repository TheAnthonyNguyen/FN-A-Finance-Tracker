<html>
<style>
        body {
        background-image: url('BG2.0.jpg');
        background-size: cover;
        color: white;
        font-family: "Times New Roman", Times, serif;
        font-size: 26px;
        list-style-type: none 
        }
        a:link {
            color: white;
            font-family: "Times New Roman", Times, serif;
        }
        a:visited {
            color: white;
            font-family: "Times New Roman", Times, serif;
        }
    </style>
     <?php
    echo "<h1> Deleted Source of Income </h1>"
    ?>
<?php

if(isset($_COOKIE['username'])) {

    $username = $_COOKIE['username'];
    $password = $_COOKIE['password'];
    $server = "vlamp.cs.uleth.ca";
    $database = "gilm3660";
    $account_number = $_POST['account_number'];
    $income_class = $_POST['income_class'];
    $amount = $_POST['amount'];


    try {
        $con = new mysqli($server, $username, $password, $database);
    }catch (Exception $e) {
        echo $e->getMessage();
    }

    $sql = "delete from INCOME where account_number='$account_number' and income_class='$income_class' and amount='$amount'";

    $result = $con->query($sql);
// fix outputed messages: says error deleting expense
    if($result->num_rows == 0) {
        echo "Successfully Deleted Income.<br>";
    } else {
        echo "Error Deleting Income.<br>" . mysqli_error($con);
    }

    echo "<a href=\"main.php\">Main Page</a>";

} else {
    echo "<h3> You are not logged in! </h3> <p><a href=\"login.php\"> Login </a></p>";
}
?>
</html>